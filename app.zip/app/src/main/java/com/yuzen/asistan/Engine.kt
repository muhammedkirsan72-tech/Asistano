package com.yuzen.asistan

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

val TR: Locale = Locale("tr", "TR")

// ---------------------------------------------------------------- Ayarlar + geçmiş
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("asst", Context.MODE_PRIVATE)

    fun get(c: Context, k: String, d: String = ""): String =
        (sp(c).getString(k, d) ?: d).ifBlank { d }

    fun put(c: Context, k: String, v: String) {
        sp(c).edit().putString(k, v).apply()
    }

    fun history(c: Context): JSONArray =
        try { JSONArray(get(c, "hist", "[]")) } catch (e: Exception) { JSONArray() }

    fun addMsg(c: Context, role: String, text: String, image: String = "") {
        val h = history(c)
        h.put(JSONObject().put("r", role).put("t", text).put("i", image))
        val out = JSONArray()
        val start = if (h.length() > 60) h.length() - 60 else 0
        for (i in start until h.length()) out.put(h.get(i))
        put(c, "hist", out.toString())
    }

    fun clearHistory(c: Context) {
        put(c, "hist", "[]")
    }
}

// ---------------------------------------------------------------- Yapay zekâ istemcileri
object Ai {
    class Msg(val role: String, val text: String)

    fun isImage(t: String): Boolean {
        val s = t.lowercase(TR)
        return s.startsWith("/resim") || s.contains("resim çiz") || s.contains("resmi çiz") ||
            s.contains("resim yap") || s.contains("resim oluştur") || s.contains("görsel oluştur") ||
            s.contains("görsel üret") || s.contains("görsel çiz") || s.startsWith("çiz ")
    }

    fun isCode(t: String): Boolean {
        val s = t.lowercase(TR)
        val keys = listOf("kod", "script", "fonksiyon", "python", "kotlin", "javascript", "html", "css", "sql", "program yaz", "uygulama yaz")
        return keys.any { s.contains(it) }
    }

    private fun system(code: Boolean): String {
        val base = "Sen Türkçe konuşan, net cevap veren bir telefon asistanısın. "
        val part = if (code) {
            "Kod yazarken tam ve çalışır kodu ``` bloğu içinde ver, kodun dışında kısa açıklama yap. "
        } else {
            "Cevapları kısa tut. "
        }
        val act = "Kullanıcı telefonda bir işlem isterse cevabının SON satırına şu eylemlerden TAM OLARAK birini yaz: " +
            "ACTION: open_app <uygulama adı> veya ACTION: back veya ACTION: home veya ACTION: recents " +
            "veya ACTION: scroll_down veya ACTION: scroll_up . Başka eylem uydurma. İşlem istenmediyse ACTION yazma."
        return base + part + act
    }

    private fun post(url: String, headers: Map<String, String>, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + txt.take(300))
        return txt
    }

    private fun normalize(msgs: List<Msg>): List<Msg> {
        val out = ArrayList<Msg>()
        for (m in msgs) {
            if (m.text.isBlank()) continue
            if (out.isNotEmpty() && out[out.size - 1].role == m.role) {
                val l = out.removeAt(out.size - 1)
                out.add(Msg(l.role, l.text + "\n" + m.text))
            } else {
                out.add(m)
            }
        }
        while (out.isNotEmpty() && out[0].role != "user") out.removeAt(0)
        return out
    }

    private fun gemini(c: Context, msgs: List<Msg>, system: String): String {
        val key = Prefs.get(c, "k_gemini")
        val model = Prefs.get(c, "m_gemini", "gemini-2.5-flash")
        val contents = JSONArray()
        for (m in msgs) {
            contents.put(
                JSONObject()
                    .put("role", if (m.role == "user") "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", m.text)))
            )
        }
        val body = JSONObject()
            .put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val r = JSONObject(
            post(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                mapOf("x-goog-api-key" to key),
                body.toString()
            )
        )
        val cands = r.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) throw RuntimeException("Gemini cevap vermedi (içerik engellenmiş olabilir)")
        val parts = cands.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    private fun groq(c: Context, msgs: List<Msg>, system: String): String {
        val key = Prefs.get(c, "k_groq")
        val model = Prefs.get(c, "m_groq", "llama-3.3-70b-versatile")
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put("content", system))
        for (m in msgs) arr.put(JSONObject().put("role", m.role).put("content", m.text))
        val body = JSONObject().put("model", model).put("messages", arr).put("temperature", 0.6)
        val r = JSONObject(
            post(
                "https://api.groq.com/openai/v1/chat/completions",
                mapOf("Authorization" to "Bearer $key"),
                body.toString()
            )
        )
        return r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content").trim()
    }

    private fun claude(c: Context, msgs: List<Msg>, system: String): String {
        val key = Prefs.get(c, "k_claude")
        val model = Prefs.get(c, "m_claude", "claude-sonnet-5-5")
        val arr = JSONArray()
        for (m in msgs) arr.put(JSONObject().put("role", m.role).put("content", m.text))
        val body = JSONObject()
            .put("model", model)
            .put("max_tokens", 2048)
            .put("system", system)
            .put("messages", arr)
        val r = JSONObject(
            post(
                "https://api.anthropic.com/v1/messages",
                mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
                body.toString()
            )
        )
        val parts = r.getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString().trim()
    }

    /** Sohbet/kod. Anahtarı olan motorları sırayla dener (Claude sadece seçildiyse kullanılır, ücretli). */
    fun chat(c: Context, msgs: List<Msg>, code: Boolean, sys: String? = null): String {
        val ms = normalize(msgs)
        if (ms.isEmpty()) throw RuntimeException("Boş mesaj")
        val system = sys ?: system(code)
        var first = if (code) Prefs.get(c, "code_engine", "gemini").lowercase() else "gemini"
        if (first != "gemini" && first != "groq" && first != "claude") first = "gemini"
        val order = listOf(first) + listOf("gemini", "groq").filter { it != first }
        var lastErr = ""
        for (e in order) {
            if (Prefs.get(c, "k_$e").isBlank()) continue
            try {
                return when (e) {
                    "gemini" -> gemini(c, ms, system)
                    "groq" -> groq(c, ms, system)
                    else -> claude(c, ms, system)
                }
            } catch (ex: Exception) {
                lastErr = e + ": " + (ex.message ?: "")
            }
        }
        throw RuntimeException(
            if (lastErr.isBlank()) "Önce uygulamayı açıp ⚙ Ayarlar'dan en az bir API anahtarı gir." else lastErr
        )
    }

    private fun save(c: Context, bytes: ByteArray): String {
        val f = File(c.filesDir, "img_" + System.currentTimeMillis() + ".png")
        f.writeBytes(bytes)
        return f.absolutePath
    }

    /** Görsel üretir, dosya yolunu döndürür. Önce Gemini, olmazsa anahtarsız yedek. */
    fun image(c: Context, prompt: String): String {
        var err = ""
        val key = Prefs.get(c, "k_gemini")
        if (key.isNotBlank()) {
            try {
                val model = Prefs.get(c, "m_image", "gemini-2.5-flash-image")
                val body = JSONObject()
                    .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                    .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
                val r = JSONObject(
                    post(
                        "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent",
                        mapOf("x-goog-api-key" to key),
                        body.toString()
                    )
                )
                val parts = r.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val d = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
                    if (d != null) {
                        return save(c, Base64.decode(d.getString("data"), Base64.DEFAULT))
                    }
                }
                err = "Gemini görsel döndürmedi"
            } catch (e: Exception) {
                err = e.message ?: ""
            }
        }
        try {
            var en = prompt
            if (Prefs.get(c, "k_gemini").isNotBlank() || Prefs.get(c, "k_groq").isNotBlank()) {
                try {
                    en = chat(
                        c,
                        listOf(Msg("user", prompt)),
                        false,
                        "Sen bir görsel prompt yazarısın. Verilen isteği detaylı, tek paragraf İngilizce görsel prompt'a çevir. Sadece prompt'u yaz."
                    ).lines().first()
                } catch (e: Exception) {
                    en = prompt
                }
            }
            val u = "https://image.pollinations.ai/prompt/" +
                URLEncoder.encode(en.take(400), "UTF-8").replace("+", "%20") +
                "?width=768&height=768&nologo=true"
            val cn = URL(u).openConnection() as HttpURLConnection
            cn.connectTimeout = 20000
            cn.readTimeout = 120000
            if (cn.responseCode !in 200..299) throw RuntimeException("HTTP " + cn.responseCode)
            val bytes = cn.inputStream.use { it.readBytes() }
            return save(c, bytes)
        } catch (e: Exception) {
            throw RuntimeException("Görsel üretilemedi. " + err + " | " + (e.message ?: ""))
        }
    }
}

// ---------------------------------------------------------------- Telefon eylemleri
object Actions {
    fun split(reply: String): Pair<String, String?> {
        val lines = reply.trimEnd().lines()
        var idx = -1
        for (i in lines.indices) if (lines[i].trim().startsWith("ACTION:")) idx = i
        if (idx < 0) return Pair(reply, null)
        val act = lines[idx].trim().removePrefix("ACTION:").trim()
        val text = lines.filterIndexed { i, _ -> i != idx }.joinToString("\n").trim()
        return Pair(text, act)
    }

    fun needsHide(act: String): Boolean = !act.lowercase(TR).startsWith("open_app")

    fun run(c: Context, act: String): String {
        val a = act.trim()
        val l = a.lowercase(TR)
        return when {
            l.startsWith("open_app") -> openApp(c, a.substring(8).trim())
            l == "back" -> glob(AccessibilityService.GLOBAL_ACTION_BACK)
            l == "home" -> glob(AccessibilityService.GLOBAL_ACTION_HOME)
            l == "recents" -> glob(AccessibilityService.GLOBAL_ACTION_RECENTS)
            l == "scroll_down" -> scroll(true)
            l == "scroll_up" -> scroll(false)
            else -> "Bilinmeyen eylem: $a"
        }
    }

    private const val NEED_A11Y = "Erişilebilirlik izni kapalı. Ayarlar > Erişilebilirlik'ten Yüzen Asistan'ı aç."

    private fun glob(g: Int): String {
        val s = A11yService.instance ?: return NEED_A11Y
        return if (s.performGlobalAction(g)) "✓" else "Eylem yapılamadı"
    }

    private fun scroll(forward: Boolean): String {
        val s = A11yService.instance ?: return NEED_A11Y
        return if (s.scroll(forward)) "✓" else "Kaydırılacak bir şey bulamadım"
    }

    private fun openApp(c: Context, name: String): String {
        if (name.isBlank()) return "Uygulama adı boş"
        val pm = c.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        val q = name.lowercase(TR)
        var pkg: String? = null
        for (r in list) {
            if (r.loadLabel(pm).toString().lowercase(TR) == q) { pkg = r.activityInfo.packageName; break }
        }
        if (pkg == null) {
            for (r in list) {
                if (r.loadLabel(pm).toString().lowercase(TR).contains(q)) { pkg = r.activityInfo.packageName; break }
            }
        }
        if (pkg == null) return "Uygulama bulunamadı: $name"
        val launch = pm.getLaunchIntentForPackage(pkg) ?: return "Uygulama açılamadı: $name"
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(launch)
        return "✓"
    }
}

// ---------------------------------------------------------------- Çekirdek: bir mesaja cevap
object Core {
    class Reply(val text: String, val image: String = "", val action: String? = null)

    fun respond(c: Context, input: String, mode: String): Reply {
        Prefs.addMsg(c, "user", input)
        try {
            val wantImage = mode == "resim" || (mode == "oto" && Ai.isImage(input))
            if (wantImage) {
                val prompt = input.removePrefix("/resim").trim().ifBlank { input }
                val path = Ai.image(c, prompt)
                Prefs.addMsg(c, "assistant", "Görsel hazır.", path)
                return Reply("Görsel hazır.", path)
            }
            val h = Prefs.history(c)
            val msgs = ArrayList<Ai.Msg>()
            val start = if (h.length() > 12) h.length() - 12 else 0
            for (i in start until h.length()) {
                val o = h.getJSONObject(i)
                msgs.add(Ai.Msg(o.optString("r"), o.optString("t")))
            }
            val code = mode == "kod" || (mode == "oto" && Ai.isCode(input))
            val raw = Ai.chat(c, msgs, code)
            val pair = Actions.split(raw)
            val text = pair.first
            val act = pair.second
            val shown = if (text.isBlank()) "Tamam." else text
            Prefs.addMsg(c, "assistant", shown)
            return Reply(shown, "", act)
        } catch (e: Exception) {
            val m = e.message ?: "Bilinmeyen hata"
            val nice = when {
                m.contains("429") -> "Ücretsiz istek limiti doldu. Biraz bekleyip tekrar dene."
                m.contains("UnknownHost") || m.contains("Unable to resolve") -> "İnternet bağlantısı yok."
                else -> m
            }
            return Reply("⚠ $nice")
        }
    }
}

// ---------------------------------------------------------------- Ses: dinle + konuş
class Voice(
    private val ctx: Context,
    private val onResult: (String) -> Unit,
    private val onState: (String) -> Unit
) {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val h = Handler(Looper.getMainLooper())

    init {
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(TR)
                ttsReady = true
            }
        }
    }

    fun hasMic(): Boolean =
        ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    fun listen() {
        if (!hasMic()) { onState("mic_izin"); return }
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onState("mic_yok"); return }
        stopListen()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        sr = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { onState("dinliyor") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) { onState("hata:$e") }
            override fun onResults(b: Bundle?) {
                val l = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val t = if (l != null && l.isNotEmpty()) l[0] else ""
                if (t.isNotBlank()) onResult(t) else onState("bos")
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
        r.startListening(i)
    }

    fun stopListen() {
        try { sr?.cancel(); sr?.destroy() } catch (e: Exception) { }
        sr = null
    }

    private fun clean(t: String): String =
        t.replace(Regex("```[\\s\\S]*?```"), " kod bloğu. ").replace(Regex("[*#`_]"), "")

    fun speak(text: String, done: (() -> Unit)?) {
        val t = tts
        if (t == null || !ttsReady) { done?.invoke(); return }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { h.post { done?.invoke() } }
            override fun onError(id: String?) { h.post { done?.invoke() } }
        })
        t.speak(clean(text).take(1500), TextToSpeech.QUEUE_FLUSH, null, "u1")
    }

    fun stopSpeak() {
        try { tts?.stop() } catch (e: Exception) { }
    }

    fun release() {
        stopListen()
        try { tts?.stop(); tts?.shutdown() } catch (e: Exception) { }
        tts = null
    }
}

// ---------------------------------------------------------------- Konuşma akışı (yazı + ses + canlı mod)
class Convo(
    private val ctx: Context,
    private val mode: () -> String,
    private val cb: Callbacks
) {
    interface Callbacks {
        fun onUser(t: String)
        fun onThinking()
        fun onReply(r: Core.Reply)
        fun onStatus(s: String)
        fun onHide()
    }

    private val h = Handler(Looper.getMainLooper())
    val voice = Voice(ctx, { t -> handle(t, true) }, { s -> state(s) })
    var live = false
    private var errs = 0
    private var released = false

    fun typed(t: String) {
        if (t.isBlank()) return
        handle(t.trim(), false)
    }

    fun mic() {
        live = false
        voice.stopSpeak()
        voice.listen()
    }

    fun toggleLive() {
        if (live) {
            live = false
            voice.stopListen()
            voice.stopSpeak()
            cb.onStatus("")
        } else {
            live = true
            errs = 0
            voice.stopSpeak()
            voice.listen()
        }
    }

    fun stopAll() {
        live = false
        voice.stopListen()
        voice.stopSpeak()
    }

    fun release() {
        released = true
        live = false
        voice.release()
    }

    private fun state(s: String) {
        if (released) return
        when {
            s == "dinliyor" -> { errs = 0; cb.onStatus("Dinliyorum…") }
            s == "mic_izin" -> { live = false; cb.onStatus("Mikrofon izni yok: uygulamayı açıp izin ver") }
            s == "mic_yok" -> { live = false; cb.onStatus("Bu telefonda ses tanıma yok") }
            else -> {
                if (live && errs < 5) {
                    errs++
                    h.postDelayed({ if (live && !released) voice.listen() }, 900)
                } else {
                    live = false
                    cb.onStatus(if (s == "hata:7" || s == "hata:6" || s == "bos") "Seni duyamadım, tekrar dene" else "Ses hatası ($s)")
                }
            }
        }
    }

    private fun handle(t: String, fromVoice: Boolean) {
        if (released) return
        cb.onUser(t)
        cb.onThinking()
        Thread {
            val r = Core.respond(ctx, t, mode())
            h.post { finish(r, fromVoice) }
        }.start()
    }

    private fun finish(r: Core.Reply, fromVoice: Boolean) {
        if (released) return
        val act = r.action
        if (act != null) {
            live = false
            if (Actions.needsHide(act)) {
                cb.onReply(r)
                cb.onHide()
                h.postDelayed({ Actions.run(ctx, act) }, 600)
                return
            }
            val n = Actions.run(ctx, act)
            if (n.startsWith("✓")) {
                cb.onReply(r)
                h.postDelayed({ cb.onHide() }, 400)
            } else {
                cb.onReply(Core.Reply(r.text + "\n" + n, r.image, null))
            }
            return
        }
        cb.onReply(r)
        val speak = (fromVoice || live) && Prefs.get(ctx, "tts", "1") != "0" &&
            r.image.isBlank() && !r.text.startsWith("⚠")
        if (speak) {
            cb.onStatus("Konuşuyor…")
            voice.speak(r.text) {
                if (live && !released) voice.listen() else cb.onStatus("")
            }
        } else if (live) {
            voice.listen()
        }
    }
}
