package com.yuzen.asistan

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

// ---------------------------------------------------------------- Varsayılan asistan servisleri
class AsstService : VoiceInteractionService()

class AsstSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AsstSession(this)
}

/** Sistemin asistan olarak listelemesi için gereken boş ses tanıma servisi. */
class AsstRecognitionService : RecognitionService() {
    override fun onStartListening(intent: Intent?, cb: Callback?) {
        try { cb?.error(SpeechRecognizer.ERROR_CLIENT) } catch (e: Exception) { }
    }
    override fun onCancel(cb: Callback?) {}
    override fun onStopListening(cb: Callback?) {}
}

// ---------------------------------------------------------------- Erişilebilirlik (geri, ana ekran, kaydırma)
class A11yService : AccessibilityService() {
    companion object {
        var instance: A11yService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = findScrollable(root) ?: return false
        val a = if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        return n.performAction(a)
    }

    private fun findScrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) {
            val ch = n.getChild(i) ?: continue
            val r = findScrollable(ch)
            if (r != null) return r
        }
        return null
    }
}

// ---------------------------------------------------------------- Çağırınca açılan alt kapsül
class AsstSession(private val svc: Context) : VoiceInteractionSession(svc) {

    private var convo: Convo? = null
    private lateinit var card: LinearLayout
    private lateinit var answer: TextView
    private lateinit var img: ImageView
    private lateinit var bar: InputBar

    override fun onCreateContentView(): View {
        val c = context
        val root = FrameLayout(c)
        root.setOnClickListener { hide() }

        val col = LinearLayout(c)
        col.orientation = LinearLayout.VERTICAL
        col.isClickable = true

        // Cevap kartı (başta gizli)
        card = LinearLayout(c)
        card.orientation = LinearLayout.VERTICAL
        card.background = K.bg(c, K.GLASS, 24, K.EDGE)
        card.elevation = K.dp(c, 6).toFloat()
        card.setPadding(K.dp(c, 16), K.dp(c, 12), K.dp(c, 16), K.dp(c, 10))
        card.visibility = View.GONE

        val maxH = (c.resources.displayMetrics.heightPixels * 0.38).toInt()
        val sc = MaxHeightScroll(c, maxH)
        answer = TextView(c)
        answer.textSize = 16f
        answer.setTextColor(K.INK)
        sc.addView(answer)
        card.addView(sc, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        img = ImageView(c)
        img.adjustViewBounds = true
        img.maxHeight = K.dp(c, 240)
        img.visibility = View.GONE
        card.addView(img, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val open = TextView(c)
        open.text = "Uygulamada aç  ↗"
        open.textSize = 14f
        open.setTextColor(K.BLUE)
        open.gravity = Gravity.END
        open.setPadding(0, K.dp(c, 8), 0, 0)
        open.setOnClickListener { openFull() }
        card.addView(open, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val clp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        clp.bottomMargin = K.dp(c, 8)
        col.addView(card, clp)

        // Alt kapsül
        bar = InputBar(c, "↗")
        bar.left.setOnClickListener { openFull() }
        col.addView(bar.view, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM)
        lp.setMargins(K.dp(c, 12), 0, K.dp(c, 12), K.dp(c, 16))
        root.addView(col, lp)

        val cv = Convo(c, { "oto" }, object : Convo.Callbacks {
            override fun onUser(t: String) {
                card.visibility = View.VISIBLE
                img.visibility = View.GONE
                answer.text = "“" + t + "”"
            }

            override fun onThinking() {
                answer.text = answer.text.toString() + "\n\nDüşünüyor…"
            }

            override fun onReply(r: Core.Reply) {
                card.visibility = View.VISIBLE
                answer.text = r.text
                if (r.image.isNotBlank()) {
                    val bm = BitmapFactory.decodeFile(r.image)
                    if (bm != null) {
                        img.setImageBitmap(bm)
                        img.visibility = View.VISIBLE
                    }
                }
                // Kod ya da görsel gelince kapsül büyüyüp uygulamaya dönüşür
                if (r.image.isNotBlank() || r.text.contains("```")) openFull()
            }

            override fun onStatus(s: String) {
                bar.edit.hint = if (s.isBlank()) "Asistana sorun" else s
                bar.paintLive(convo?.live == true)
            }

            override fun onHide() {
                this@AsstSession.hide()
            }
        })
        convo = cv

        bar.onSend { cv.typed(it) }
        bar.mic.setOnClickListener { cv.mic() }
        bar.live.setOnClickListener {
            cv.toggleLive()
            bar.paintLive(cv.live)
        }
        return root
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            val w = window?.window
            if (w != null) {
                w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                w.setGravity(Gravity.BOTTOM)
                w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
            }
        } catch (e: Exception) { }
        card.visibility = View.GONE
        img.visibility = View.GONE
        bar.edit.setText("")
        bar.edit.hint = "Asistana sorun"
        bar.paintLive(false)
    }

    override fun onHide() {
        convo?.stopAll()
        super.onHide()
    }

    override fun onDestroy() {
        convo?.release()
        super.onDestroy()
    }

    private fun openFull() {
        val i = Intent(context, ChatActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        try {
            context.startActivity(i)
        } catch (e: Exception) {
            try { startAssistantActivity(i) } catch (e2: Exception) { }
        }
        hide()
    }
}
