package com.yuzen.asistan

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.EditText
import java.io.File

class ChatActivity : Activity() {

    private lateinit var list: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var bar: InputBar
    private lateinit var convo: Convo
    private lateinit var status: TextView
    private val chips = LinkedHashMap<String, TextView>()
    private var thinking: View? = null

    private val mp = ViewGroup.LayoutParams.MATCH_PARENT
    private val wc = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun dp(v: Int): Int = K.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#F4F6FB"))

        // Üst çubuk
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(dp(16), dp(12), dp(8), dp(4))
        val title = TextView(this)
        title.text = "Asistan"
        title.textSize = 24f
        title.typeface = Typeface.DEFAULT_BOLD
        title.setTextColor(K.INK)
        head.addView(title, LinearLayout.LayoutParams(0, wc, 1f))
        val gear = K.roundBtn(this, "⚙", Color.TRANSPARENT, 44)
        gear.setOnClickListener { showSettings() }
        val trash = K.roundBtn(this, "🗑", Color.TRANSPARENT, 44)
        trash.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Sohbeti temizle?")
                .setPositiveButton("Temizle") { _, _ ->
                    Prefs.clearHistory(this)
                    list.removeAllViews()
                    greet()
                }
                .setNegativeButton("İptal", null)
                .show()
        }
        head.addView(gear)
        head.addView(trash)
        root.addView(head, LinearLayout.LayoutParams(mp, wc))

        // Mod seçenekleri
        val row = LinearLayout(this)
        row.setPadding(dp(12), dp(4), dp(12), dp(8))
        val modes = listOf("oto" to "Otomatik", "sohbet" to "Sohbet", "kod" to "Kod", "resim" to "Resim")
        for (m in modes) {
            val k = m.first
            val t = TextView(this)
            t.text = m.second
            t.textSize = 14f
            t.gravity = Gravity.CENTER
            t.setPadding(dp(14), dp(8), dp(14), dp(8))
            t.setOnClickListener {
                Prefs.put(this, "mode", k)
                paintChips()
            }
            val lp = LinearLayout.LayoutParams(wc, wc)
            lp.rightMargin = dp(8)
            row.addView(t, lp)
            chips[k] = t
        }
        paintChips()
        root.addView(row, LinearLayout.LayoutParams(mp, wc))

        // Mesaj listesi
        scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(12), dp(4), dp(12), dp(12))
        scroll.addView(list, ViewGroup.LayoutParams(mp, wc))
        root.addView(scroll, LinearLayout.LayoutParams(mp, 0, 1f))

        status = TextView(this)
        status.textSize = 12f
        status.setTextColor(Color.GRAY)
        status.setPadding(dp(20), dp(2), dp(20), dp(2))
        root.addView(status, LinearLayout.LayoutParams(mp, wc))

        // Alt kapsül
        bar = InputBar(this, "")
        bar.left.visibility = View.GONE
        val blp = LinearLayout.LayoutParams(mp, wc)
        blp.setMargins(dp(10), dp(2), dp(10), dp(10))
        root.addView(bar.view, blp)

        setContentView(root)

        convo = Convo(this, { Prefs.get(this, "mode", "oto") }, object : Convo.Callbacks {
            override fun onUser(t: String) { addUser(t) }
            override fun onThinking() { showThinking() }
            override fun onReply(r: Core.Reply) {
                removeThinking()
                addAssistant(r.text, r.image)
            }
            override fun onStatus(s: String) {
                status.text = s
                bar.paintLive(convo.live)
            }
            override fun onHide() { moveTaskToBack(true) }
        })

        bar.onSend { convo.typed(it) }
        bar.mic.setOnClickListener { convo.mic() }
        bar.live.setOnClickListener {
            convo.toggleLive()
            bar.paintLive(convo.live)
        }

        // Geçmişi göster
        val h = Prefs.history(this)
        if (h.length() == 0) {
            greet()
        } else {
            for (i in 0 until h.length()) {
                val o = h.getJSONObject(i)
                if (o.optString("r") == "user") addUser(o.optString("t"))
                else addAssistant(o.optString("t"), o.optString("i"))
            }
        }
    }

    override fun onDestroy() {
        convo.release()
        super.onDestroy()
    }

    private fun greet() {
        addAssistant(
            "Merhaba! Sohbet edebilir, kod yazdırabilir, resim çizdirebilir ya da telefonu yönettirebilirsin.\n\n" +
                "İlk iş: sağ üstteki ⚙ düğmesinden Gemini API anahtarını gir (aistudio.google.com/apikey, ücretsiz).",
            ""
        )
    }

    private fun paintChips() {
        val cur = Prefs.get(this, "mode", "oto")
        for ((k, t) in chips) {
            val on = k == cur
            t.background = K.bg(this, if (on) K.BLUE else Color.WHITE, 18, if (on) 0 else K.EDGE)
            t.setTextColor(if (on) Color.WHITE else K.INK)
        }
    }

    private fun down() {
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun addUser(t: String) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 16f
        tv.setTextColor(Color.WHITE)
        tv.setTextIsSelectable(true)
        tv.background = K.bg(this, K.BLUE, 18)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        val lp = LinearLayout.LayoutParams(wc, wc)
        lp.gravity = Gravity.END
        lp.setMargins(dp(48), dp(4), 0, dp(4))
        list.addView(tv, lp)
        down()
    }

    private fun showThinking() {
        val tv = TextView(this)
        tv.text = "Düşünüyor…"
        tv.textSize = 15f
        tv.setTextColor(Color.GRAY)
        tv.setPadding(dp(14), dp(8), dp(14), dp(8))
        list.addView(tv, LinearLayout.LayoutParams(wc, wc))
        thinking = tv
        down()
    }

    private fun removeThinking() {
        val t = thinking
        if (t != null) list.removeView(t)
        thinking = null
    }

    private fun lpm(): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(mp, wc)
        l.setMargins(0, dp(6), 0, dp(6))
        return l
    }

    private fun plain(t: String): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = 16f
        tv.setTextColor(K.INK)
        tv.setTextIsSelectable(true)
        return tv
    }

    private fun codeBlock(code: String): View {
        val wrap = LinearLayout(this)
        wrap.orientation = LinearLayout.VERTICAL
        wrap.background = K.bg(this, Color.parseColor("#1E1E2E"), 12)
        wrap.setPadding(dp(10), dp(6), dp(10), dp(10))

        val copy = TextView(this)
        copy.text = "Kopyala"
        copy.textSize = 13f
        copy.setTextColor(Color.parseColor("#9CC2FF"))
        copy.gravity = Gravity.END
        copy.setPadding(0, dp(4), 0, dp(6))
        copy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("kod", code))
            Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }

        val tv = TextView(this)
        tv.text = code
        tv.typeface = Typeface.MONOSPACE
        tv.textSize = 13f
        tv.setTextColor(Color.WHITE)
        tv.setTextIsSelectable(true)
        val hs = HorizontalScrollView(this)
        hs.addView(tv)

        wrap.addView(copy, LinearLayout.LayoutParams(mp, wc))
        wrap.addView(hs)
        return wrap
    }

    private fun addAssistant(text: String, image: String) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = K.bg(this, Color.WHITE, 18)
        box.setPadding(dp(14), dp(10), dp(14), dp(10))

        val re = Regex("```[a-zA-Z0-9+#_-]*\\n?([\\s\\S]*?)```")
        var last = 0
        for (m in re.findAll(text)) {
            val before = text.substring(last, m.range.first).trim()
            if (before.isNotEmpty()) box.addView(plain(before))
            box.addView(codeBlock(m.groupValues[1].trimEnd()), lpm())
            last = m.range.last + 1
        }
        val rest = text.substring(last).trim()
        if (rest.isNotEmpty()) box.addView(plain(rest))

        if (image.isNotEmpty()) {
            val bm = BitmapFactory.decodeFile(image)
            if (bm != null) {
                val iv = ImageView(this)
                iv.adjustViewBounds = true
                iv.setImageBitmap(bm)
                iv.setOnLongClickListener {
                    saveToGallery(image)
                    true
                }
                box.addView(iv, lpm())
                val cap = TextView(this)
                cap.text = "Galeriye kaydetmek için resme uzun bas"
                cap.textSize = 12f
                cap.setTextColor(Color.GRAY)
                box.addView(cap)
            }
        }

        val lp = LinearLayout.LayoutParams(mp, wc)
        lp.setMargins(0, dp(4), dp(24), dp(4))
        list.addView(box, lp)
        down()
    }

    private fun saveToGallery(path: String) {
        try {
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "asistan_" + System.currentTimeMillis() + ".png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Asistan")
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)!!
            contentResolver.openOutputStream(uri)!!.use { o ->
                File(path).inputStream().use { it.copyTo(o) }
            }
            Toast.makeText(this, "Galeriye kaydedildi", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Kaydedilemedi", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSettings() {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(8), dp(20), dp(8))
        val fields = LinkedHashMap<String, EditText>()

        val info = TextView(this)
        info.text = "Ücretsiz Gemini anahtarı: aistudio.google.com/apikey\nÜcretsiz Groq anahtarı: console.groq.com/keys"
        info.textSize = 13f
        col.addView(info)

        fun add(label: String, key: String, def: String) {
            val l = TextView(this)
            l.text = label
            l.textSize = 13f
            l.setPadding(0, dp(12), 0, 0)
            col.addView(l)
            val e = EditText(this)
            e.setSingleLine(true)
            e.setText(Prefs.get(this, key, def))
            col.addView(e)
            fields[key] = e
        }
        add("Gemini API anahtarı", "k_gemini", "")
        add("Groq API anahtarı (yedek, ücretsiz)", "k_groq", "")
        add("Claude API anahtarı (isteğe bağlı, ücretli)", "k_claude", "")
        add("Kod için motor: gemini / groq / claude", "code_engine", "gemini")
        add("Gemini modeli", "m_gemini", "gemini-2.5-flash")
        add("Groq modeli", "m_groq", "llama-3.3-70b-versatile")
        add("Claude modeli", "m_claude", "claude-sonnet-5-5")
        add("Görsel modeli (Gemini)", "m_image", "gemini-2.5-flash-image")
        add("Sesli yanıt (1 açık, 0 kapalı)", "tts", "1")

        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this)
            .setTitle("Ayarlar")
            .setView(sv)
            .setPositiveButton("Kaydet") { _, _ ->
                for ((k, e) in fields) Prefs.put(this, k, e.text.toString().trim())
                Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("İptal", null)
            .show()
    }
}
