package com.yuzen.asistan

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

object K {
    val BLUE: Int = Color.parseColor("#1A73E8")
    val SOFTBLUE: Int = Color.parseColor("#D3E3FD")
    val GREY: Int = Color.parseColor("#EEF1F6")
    val INK: Int = Color.parseColor("#1F1F1F")
    val GLASS: Int = Color.parseColor("#F7FFFFFF")
    val EDGE: Int = Color.parseColor("#26000000")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density + 0.5f).toInt()

    fun bg(c: Context, color: Int, radiusDp: Int, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(c, radiusDp).toFloat()
        if (strokeColor != 0) g.setStroke(dp(c, 1), strokeColor)
        return g
    }

    fun roundBtn(c: Context, label: String, fill: Int, sizeDp: Int): TextView {
        val t = TextView(c)
        t.text = label
        t.textSize = 20f
        t.gravity = Gravity.CENTER
        t.setTextColor(INK)
        t.background = bg(c, fill, sizeDp / 2)
        t.layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        return t
    }
}

class MaxHeightScroll(c: Context, private val maxPx: Int) : ScrollView(c) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, View.MeasureSpec.makeMeasureSpec(maxPx, View.MeasureSpec.AT_MOST))
    }
}

/** Gemini tarzı alt kapsül: [sol düğme] [yazı alanı] [mikrofon] [canlı ses] */
class InputBar(private val c: Context, leftLabel: String) {
    val left: TextView = K.roundBtn(c, leftLabel, Color.TRANSPARENT, 44)
    val edit: EditText = EditText(c)
    val mic: TextView = K.roundBtn(c, "🎤", K.SOFTBLUE, 44)
    val live: TextView = K.roundBtn(c, "🎧", K.GREY, 44)
    val view: LinearLayout = LinearLayout(c)

    init {
        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.background = K.bg(c, K.GLASS, 32, K.EDGE)
        view.elevation = K.dp(c, 6).toFloat()
        view.setPadding(K.dp(c, 6), K.dp(c, 6), K.dp(c, 6), K.dp(c, 6))

        edit.hint = "Asistana sorun"
        edit.setSingleLine(true)
        edit.inputType = InputType.TYPE_CLASS_TEXT
        edit.imeOptions = EditorInfo.IME_ACTION_SEND
        edit.background = null
        edit.textSize = 17f
        edit.setTextColor(K.INK)
        edit.setPadding(K.dp(c, 8), 0, K.dp(c, 8), 0)

        view.addView(left)
        view.addView(edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        view.addView(mic)
        view.addView(live)
        (mic.layoutParams as LinearLayout.LayoutParams).leftMargin = K.dp(c, 4)
        (live.layoutParams as LinearLayout.LayoutParams).leftMargin = K.dp(c, 6)
    }

    fun onSend(f: (String) -> Unit) {
        edit.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND || id == EditorInfo.IME_ACTION_DONE) {
                val t = edit.text.toString()
                edit.setText("")
                f(t)
                true
            } else {
                false
            }
        }
    }

    fun paintLive(on: Boolean) {
        live.background = K.bg(c, if (on) K.BLUE else K.GREY, 22)
    }
}
